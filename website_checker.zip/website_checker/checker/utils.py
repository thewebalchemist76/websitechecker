# utils.py

# Define the utility functions here, for example:
def get_business_summary(website_text):
    # Your implementation for getting the business summary
    pass

def extract_emails(website_text):
    # Your implementation for extracting emails
    pass

def extract_phones(website_text):
    # Your implementation for extracting phone numbers
    pass

def extract_social_media_links(soup):
    # Your implementation for extracting social media links
    pass
